{
    "isSuccess": true,
    "code": "0002",
    "info": "已关注"
}