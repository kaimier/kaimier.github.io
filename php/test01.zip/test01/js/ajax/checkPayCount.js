[{
    "projectId": 6883,
    "couldPay": false,
    "typeMsg": "普通投资",
    "count": 0
}, {
    "projectId": 6883,
    "couldPay": false,
    "typeMsg": "小东家投资",
    "count": 0
}]