{
    "info": null,
    "code": "0",
    "success": true,
    "txnStatus": null
}