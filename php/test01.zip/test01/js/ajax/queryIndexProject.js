{
    "result": {
        "isSuccess": true,
        "code": "1",
        "txnStatus": "1"
    },
    "projectHomeResponseVoList": [{
        "projectId": 7199,
        "projectName": "nut智能防丢硬件",
        "projectIntroduce": "手机、汽车、钱包、贵重物品、老人、孩子、宠物寻找、追踪、防丢。7亿微信用户一起帮助找的防丢网络！",
        "projectImg": "http://img30.360buyimg.com/cf/jfs/t1945/67/1458807096/250704/979f1fb6/565d0e6bNc9739984.jpg",
        "projectImgZf": "http://img30.360buyimg.com/cf/jfs/t1948/64/1482908624/54432/f21e17ab/565d0e65N48ea558f.jpg",
        "projectImgCf": "http://img30.360buyimg.com/cf/jfs/t2161/142/1472418434/66552/75e880a4/565d0e5aN42b1d7a3.jpg",
        "amount": 1600.00,
        "sellShares": 1140,
        "collectAmount": 1500.00,
        "surplusDay": "NotBeginning",
        "progress": "93",
        "projectImgM": "http://img30.360buyimg.com/cf/jfs/t2332/105/1461142833/63944/84dc1c1c/565d0e77N4ad89f7b.jpg",
        "projectStatus": 500,
        "projectStatusName": "路演中",
        "projectModel": 0
    }],
    "serverTime": "2015-12-03 17:38:14",
    "pageInfo": {
        "startRow": 0,
        "endRow": 5,
        "pageSize": 5,
        "pageNo": 1,
        "pageCount": 2,
        "totalCount": 10
    },
    "projectHomeResponseVoCount": 1
}